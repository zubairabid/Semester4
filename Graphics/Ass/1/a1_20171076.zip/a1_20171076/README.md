A jetpack joyride inspired game using OpenGL 3

## Running
This comes with a preinstalled binary. Navigate to `./output` and run `./graphics_asgn1`

## Playing
Right and Left arrows to move right/left across the screen

Spacebar to Jump

Up arrow to shoot

## Implemented
Basic: all

Bonus: Dragon, Shield/sword


License
-------
The MIT License https://meghprkh.mit-license.org/

Copyright &copy; 2018 Megh Parikh <meghprkh@gmail.com>
