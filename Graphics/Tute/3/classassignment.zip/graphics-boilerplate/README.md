Graphics Boilerplate Code
=========================

This is boilerplate code for the assignments which might be helpful.


License
-------
The MIT License https://meghprkh.mit-license.org/

Copyright &copy; 2018 Megh Parikh <meghprkh@gmail.com>
