# Computer Networks Assignment 1
A client and server program in C using sockets

### Usage
Open the `Client` and `Server` directories in different terminals

Launch server with `./server` and then test out client:

```
./client
listall
send nofile.txt
send food.txt
```
